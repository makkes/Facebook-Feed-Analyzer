#!/bin/sh

java -jar facebook-feed-analyzer.jar $1
